caminho = "campeonato-brasileiro.csv"

maracana = 0
morumbi = 0

with open(caminho, "r", encoding="utf-8") as arquivo:
    linhas = arquivo.readlines()

for linha in linhas:
    informacoes = linha.strip().split(";")

    if len(informacoes) > 11:# len é o tamanho da lista, ou seja, quantos elementos tem na lista
        estadio = informacoes[11].strip().lower()

        if "maracanã" in estadio:
            maracana += 1
        elif "morumbi" in estadio:
            morumbi += 1

print(f"Jogos no Maracanã: {maracana}")
print(f"Jogos no Morumbi: {morumbi}")
