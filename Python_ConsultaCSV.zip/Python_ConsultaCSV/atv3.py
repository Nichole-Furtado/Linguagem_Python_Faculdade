caminho = "crimes_brasil_uf.csv"
import csv
with open(caminho, "r", encoding="utf-8") as arquivo:
    linhas = arquivo.readlines()

cabecalho = linhas[0].strip().split(';')
dados = linhas[1:]

total = 0

print("\nQuantos casos de roubo de banco aconteceram no Paraná:")

for linha in dados:
    informacoes = linha.strip().split(";")

    estado = informacoes[0].strip().lower()
    crime = informacoes[1].strip().lower()
    ocorrencias = int(informacoes[2])

    if estado == "paraná" and crime == "roubo a instituição financeira":
        total += ocorrencias

print(f"Total de casos: {total}")
