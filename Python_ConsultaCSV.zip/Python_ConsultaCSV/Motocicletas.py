# Quantas motocicletas existem no estado do Paraná?

caminho = 'cidades_do_brasil.csv'
import csv

def contar(caminho_arquivo):
    total = 0
    with open(caminho_arquivo, 'r', encoding='utf-8') as f:
        linhas = f.readlines()

        cabecalho = linhas[0].strip().split(';')
        index_estado = cabecalho.index('STATE')
        index_moto = cabecalho.index('Motorcycles')

        
        for linha in linhas[1:]:
            colunas = linha.strip().split(';')
            if colunas[index_estado] == 'PR':
                total += int(colunas[index_moto]) 
              
    return total

print("A quantidade de motos no PR é:",contar(r"cidades_do_brasil.csv"))
